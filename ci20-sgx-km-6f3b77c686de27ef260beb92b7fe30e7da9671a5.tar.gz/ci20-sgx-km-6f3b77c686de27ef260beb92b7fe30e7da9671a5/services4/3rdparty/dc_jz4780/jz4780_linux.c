/**********************************************************************
 *
 * Copyright (C) Imagination Technologies Ltd. All rights reserved.
 * 
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 * 
 * This program is distributed in the hope it will be useful but, except 
 * as otherwise stated in writing, without any warranty; without even the 
 * implied warranty of merchantability or fitness for a particular purpose. 
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
 * 
 * The full GNU General Public License is included in this distribution in
 * the file called "COPYING".
 *
 * Contact Information:
 * Imagination Technologies Ltd. <gpl-support@imgtec.com>
 * Home Park Estate, Kings Langley, Herts, WD4 8LZ, UK 
 *
 ******************************************************************************/

#include <linux/version.h>

#if (LINUX_VERSION_CODE < KERNEL_VERSION(2,6,38))
#ifndef AUTOCONF_INCLUDED
#include <linux/config.h>
#endif
#endif

#include <asm/atomic.h>

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/hardirq.h>
#include <linux/mutex.h>
#include <linux/workqueue.h>
#include <linux/fb.h>
#include <linux/console.h>
#include <linux/mutex.h>

#include "img_defs.h"

#if defined(SUPPORT_DRI_DRM)
#include <drm/drmP.h>
#include "pvr_drm.h"
#include "3rdparty_dc_drm_shared.h"
#endif

#include "servicesext.h"
#include "kerneldisplay.h"
#include "dc_jz4780.h"
#include "pvrmodule.h"

#if !defined(PVR_LINUX_USING_WORKQUEUES)
#error "PVR_LINUX_USING_WORKQUEUES must be defined"
#endif

MODULE_SUPPORTED_DEVICE(DEVNAME);

int PVR_DRM_MAKENAME(DISPLAY_CONTROLLER, _Suspend)(struct drm_device unref__ *dev)
{
	return 0;
}

int PVR_DRM_MAKENAME(DISPLAY_CONTROLLER, _Resume)(struct drm_device unref__ *dev)
{
	return 0;
}

void *DC_JZ4780AllocKernelMem(unsigned long ulSize)
{
	return kmalloc(ulSize, GFP_KERNEL);
}

void DC_JZ4780FreeKernelMem(void *pvMem)
{
	kfree(pvMem);
}

void DC_JZ4780CreateSwapChainLockInit(DC_JZ4780_DEVINFO *psDevInfo)
{
	mutex_init(&psDevInfo->sCreateSwapChainMutex);
}

void DC_JZ4780CreateSwapChainLockDeInit(DC_JZ4780_DEVINFO *psDevInfo)
{
	mutex_destroy(&psDevInfo->sCreateSwapChainMutex);
}

void DC_JZ4780CreateSwapChainLock(DC_JZ4780_DEVINFO *psDevInfo)
{
	mutex_lock(&psDevInfo->sCreateSwapChainMutex);
}

void DC_JZ4780CreateSwapChainUnLock(DC_JZ4780_DEVINFO *psDevInfo)
{
	mutex_unlock(&psDevInfo->sCreateSwapChainMutex);
}

void DC_JZ4780AtomicBoolInit(DC_JZ4780_ATOMIC_BOOL *psAtomic, bool bVal)
{
	atomic_set(psAtomic, (int)bVal);
}

void DC_JZ4780AtomicBoolDeInit(DC_JZ4780_ATOMIC_BOOL *psAtomic)
{
}

void DC_JZ4780AtomicBoolSet(DC_JZ4780_ATOMIC_BOOL *psAtomic, bool bVal)
{
	atomic_set(psAtomic, (int)bVal);
}

bool DC_JZ4780AtomicBoolRead(DC_JZ4780_ATOMIC_BOOL *psAtomic)
{
	return (bool)atomic_read(psAtomic);
}

void DC_JZ4780AtomicIntInit(DC_JZ4780_ATOMIC_INT *psAtomic, int iVal)
{
	atomic_set(psAtomic, iVal);
}

void DC_JZ4780AtomicIntDeInit(DC_JZ4780_ATOMIC_INT *psAtomic)
{
}

void DC_JZ4780AtomicIntSet(DC_JZ4780_ATOMIC_INT *psAtomic, int iVal)
{
	atomic_set(psAtomic, iVal);
}

int DC_JZ4780AtomicIntRead(DC_JZ4780_ATOMIC_INT *psAtomic)
{
	return atomic_read(psAtomic);
}

void DC_JZ4780AtomicIntInc(DC_JZ4780_ATOMIC_INT *psAtomic)
{
	atomic_inc(psAtomic);
}

DC_JZ4780_ERROR DC_JZ4780GetLibFuncAddr (char *szFunctionName, PFN_DC_GET_PVRJTABLE *ppfnFuncTable)
{
	if(strcmp("PVRGetDisplayClassJTable", szFunctionName) != 0)
	{
		return (DC_JZ4780_ERROR_INVALID_PARAMS);
	}

	/* Nothing to do - should be exported from pvrsrv.ko */
	*ppfnFuncTable = PVRGetDisplayClassJTable;

	return (DC_JZ4780_OK);
}

/* Inset a swap buffer into the swap chain work queue */
void DC_JZ4780QueueBufferForSwap(DC_JZ4780_SWAPCHAIN *psSwapChain, DC_JZ4780_BUFFER *psBuffer)
{
	int res = queue_work(psSwapChain->psWorkQueue, &psBuffer->sWork);

	if (res == 0)
	{
		printk(KERN_WARNING DRIVER_PREFIX ": %s: Device %u: Buffer already on work queue\n", __FUNCTION__, psSwapChain->uiFBDevID);
	}
}

/* Process an item on a swap chain work queue */
static void WorkQueueHandler(struct work_struct *psWork)
{
	DC_JZ4780_BUFFER *psBuffer = container_of(psWork, DC_JZ4780_BUFFER, sWork);

	DC_JZ4780SwapHandler(psBuffer);
}

/* Create a swap chain work queue */
DC_JZ4780_ERROR DC_JZ4780CreateSwapQueue(DC_JZ4780_SWAPCHAIN *psSwapChain)
{
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,37))
	/*
	 * Calling alloc_ordered_workqueue with the WQ_FREEZABLE and
	 * WQ_MEM_RECLAIM flags set, (currently) has the same effect as
	 * calling create_freezable_workqueue. None of the other WQ
	 * flags are valid. Setting WQ_MEM_RECLAIM should allow the
	 * workqueue to continue to service the swap chain in low memory
	 * conditions, preventing the driver from holding on to
	 * resources longer than it needs to.
	 */
	psSwapChain->psWorkQueue = alloc_ordered_workqueue(DEVNAME, WQ_FREEZABLE | WQ_MEM_RECLAIM);
#else
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,36))
	psSwapChain->psWorkQueue = create_freezable_workqueue(DEVNAME);
#else
	/*
	 * Create a single-threaded, freezable, rt-prio workqueue.
	 * Such workqueues are frozen with user threads when a system
	 * suspends, before driver suspend entry points are called.
	 * This ensures this driver will not call into the Linux
	 * framebuffer driver after the latter is suspended.
	 */
	psSwapChain->psWorkQueue = __create_workqueue(DEVNAME, 1, 1, 1);
#endif
#endif
	if (!psSwapChain->psWorkQueue) {
		printk(KERN_ERR DRIVER_PREFIX ": %s: Device %u: Couldn't create workqueue\n", __FUNCTION__, psSwapChain->uiFBDevID);
		return (DC_JZ4780_ERROR_INIT_FAILURE);
	}

	return (DC_JZ4780_OK);
}

/* Prepare buffer for insertion into a swap chain work queue */
void DC_JZ4780InitBufferForSwap(DC_JZ4780_BUFFER *psBuffer)
{
	INIT_WORK(&psBuffer->sWork, WorkQueueHandler);
}

/* Destroy a swap chain work queue */
void DC_JZ4780DestroySwapQueue(DC_JZ4780_SWAPCHAIN *psSwapChain)
{
	destroy_workqueue(psSwapChain->psWorkQueue);
}

/* Flip display to given buffer */
void DC_JZ4780Flip(DC_JZ4780_DEVINFO *psDevInfo, DC_JZ4780_BUFFER *psBuffer)
{
	struct fb_var_screeninfo sFBVar;
	int res;
	unsigned long ulYResVirtual;

	DC_JZ4780_CONSOLE_LOCK();

	sFBVar = psDevInfo->psLINFBInfo->var;

	sFBVar.xoffset = 0;
	sFBVar.yoffset = psBuffer->ulYOffset;

	ulYResVirtual = psBuffer->ulYOffset + sFBVar.yres;

	if (sFBVar.xres_virtual != sFBVar.xres || sFBVar.yres_virtual < ulYResVirtual)
	{
		sFBVar.xres_virtual = sFBVar.xres;
		sFBVar.yres_virtual = ulYResVirtual;

		sFBVar.activate = FB_ACTIVATE_NOW | FB_ACTIVATE_FORCE;

		res = fb_set_var(psDevInfo->psLINFBInfo, &sFBVar);
		if (res != 0)
		{
			printk(KERN_ERR DRIVER_PREFIX ": %s: Device %u: fb_set_var failed (Y Offset: %lu, Error: %d)\n", __FUNCTION__, psDevInfo->uiFBDevID, psBuffer->ulYOffset, res);
		}
	}
	else
	{
		res = fb_pan_display(psDevInfo->psLINFBInfo, &sFBVar);
                
		if (res != 0)
		{
                    printk(KERN_ERR DRIVER_PREFIX ": %s: Device %u: fb_pan_display failed (Y Offset: %lu, Error: %d)\n", __FUNCTION__, psDevInfo->uiFBDevID, psBuffer->ulYOffset, res);
		}
	}

	DC_JZ4780_CONSOLE_UNLOCK();
}

/* Linux Framebuffer event notification handler */
static int DC_JZ4780FrameBufferEvents(struct notifier_block *psNotif,
                             unsigned long event, void *data)
{
	DC_JZ4780_DEVINFO *psDevInfo;
	struct fb_event *psFBEvent = (struct fb_event *)data;
	struct fb_info *psFBInfo = psFBEvent->info;
	bool bBlanked;

	/* Only interested in blanking events */
	if (event != FB_EVENT_BLANK)
		return 0;

	bBlanked = *(IMG_INT *)psFBEvent->data != 0;

	psDevInfo = DC_JZ4780GetDevInfoPtr(psFBInfo->node);
	if (psDevInfo != NULL) {
		DC_JZ4780AtomicBoolSet(&psDevInfo->sBlanked, bBlanked);
		DC_JZ4780AtomicIntInc(&psDevInfo->sBlankEvents);
	}

	return 0;
}

/* Unblank the screen */
DC_JZ4780_ERROR DC_JZ4780UnblankDisplay(DC_JZ4780_DEVINFO *psDevInfo)
{
	int res;

	DC_JZ4780_CONSOLE_LOCK();
	res = fb_blank(psDevInfo->psLINFBInfo, 0);
	DC_JZ4780_CONSOLE_UNLOCK();
	if (res != 0 && res != -EINVAL)
	{
		printk(KERN_ERR DRIVER_PREFIX
			": %s: Device %u: fb_blank failed (%d)\n", __FUNCTION__, psDevInfo->uiFBDevID, res);
		return (DC_JZ4780_ERROR_GENERIC);
	}

	return (DC_JZ4780_OK);
}

#ifdef CONFIG_HAS_EARLYSUSPEND

/* Blank the screen */
static void DC_JZ4780BlankDisplay(DC_JZ4780_DEVINFO *psDevInfo)
{
	DC_JZ4780_CONSOLE_LOCK();
	fb_blank(psDevInfo->psLINFBInfo, 1);
	DC_JZ4780_CONSOLE_UNLOCK();
}

static void DC_JZ4780EarlySuspendHandler(struct early_suspend *h)
{
	unsigned uiMaxFBDevIDPlusOne = DC_JZ4780MaxFBDevIDPlusOne();
	unsigned i;

	for (i=0; i < uiMaxFBDevIDPlusOne; i++)
	{
		DC_JZ4780_DEVINFO *psDevInfo = DC_JZ4780GetDevInfoPtr(i);

		if (psDevInfo != NULL)
		{
			DC_JZ4780AtomicBoolSet(&psDevInfo->sEarlySuspendFlag, true);
			DC_JZ4780BlankDisplay(psDevInfo);
		}
	}
}

static void DC_JZ4780EarlyResumeHandler(struct early_suspend *h)
{
	unsigned uiMaxFBDevIDPlusOne = DC_JZ4780MaxFBDevIDPlusOne();
	unsigned i;

	for (i=0; i < uiMaxFBDevIDPlusOne; i++)
	{
		DC_JZ4780_DEVINFO *psDevInfo = DC_JZ4780GetDevInfoPtr(i);

		if (psDevInfo != NULL)
		{
			DC_JZ4780UnblankDisplay(psDevInfo);
			DC_JZ4780AtomicBoolSet(&psDevInfo->sEarlySuspendFlag, false);
		}
	}
}

#endif 

/* Set up Linux Framebuffer event notification */
DC_JZ4780_ERROR DC_JZ4780EnableLFBEventNotification(DC_JZ4780_DEVINFO *psDevInfo)
{
	int                res;
	DC_JZ4780_ERROR        eError;

	/* Set up Linux Framebuffer event notification */
	memset(&psDevInfo->sLINNotifBlock, 0, sizeof(psDevInfo->sLINNotifBlock));

	psDevInfo->sLINNotifBlock.notifier_call = DC_JZ4780FrameBufferEvents;

	DC_JZ4780AtomicBoolSet(&psDevInfo->sBlanked, false);
	DC_JZ4780AtomicIntSet(&psDevInfo->sBlankEvents, 0);

	res = fb_register_client(&psDevInfo->sLINNotifBlock);
	if (res != 0)
	{
		printk(KERN_ERR DRIVER_PREFIX
			": %s: Device %u: fb_register_client failed (%d)\n", __FUNCTION__, psDevInfo->uiFBDevID, res);

		return (DC_JZ4780_ERROR_GENERIC);
	}

	eError = DC_JZ4780UnblankDisplay(psDevInfo);
	if (eError != DC_JZ4780_OK)
	{
		printk(KERN_ERR DRIVER_PREFIX
			": %s: Device %u: UnblankDisplay failed (%d)\n", __FUNCTION__, psDevInfo->uiFBDevID, eError);
		return eError;
	}

#ifdef CONFIG_HAS_EARLYSUSPEND
	psDevInfo->sEarlySuspend.suspend = DC_JZ4780EarlySuspendHandler;
	psDevInfo->sEarlySuspend.resume = DC_JZ4780EarlyResumeHandler;
	psDevInfo->sEarlySuspend.level = EARLY_SUSPEND_LEVEL_DISABLE_FB + 1;
	register_early_suspend(&psDevInfo->sEarlySuspend);
#endif

	return (DC_JZ4780_OK);
}

/* Disable Linux Framebuffer event notification */
DC_JZ4780_ERROR DC_JZ4780DisableLFBEventNotification(DC_JZ4780_DEVINFO *psDevInfo)
{
	int res;

#ifdef CONFIG_HAS_EARLYSUSPEND
	unregister_early_suspend(&psDevInfo->sEarlySuspend);
#endif

	/* Unregister for Framebuffer events */
	res = fb_unregister_client(&psDevInfo->sLINNotifBlock);
	if (res != 0)
	{
		printk(KERN_ERR DRIVER_PREFIX
			": %s: Device %u: fb_unregister_client failed (%d)\n", __FUNCTION__, psDevInfo->uiFBDevID, res);
		return (DC_JZ4780_ERROR_GENERIC);
	}

	DC_JZ4780AtomicBoolSet(&psDevInfo->sBlanked, false);

	return (DC_JZ4780_OK);
}

#if defined(SUPPORT_DRI_DRM)
int PVR_DRM_MAKENAME(DISPLAY_CONTROLLER, _Init)(struct drm_device unref__ *dev)
#else
static int __init DC_JZ4780_Init(void)
#endif
{
	if (DC_JZ4780Init() != DC_JZ4780_OK)
		return -ENODEV;

	return 0;
}

#if defined(SUPPORT_DRI_DRM)
void PVR_DRM_MAKENAME(DISPLAY_CONTROLLER, _Cleanup)(struct drm_device unref__ *dev)
#else
static void __exit DC_JZ4780_Cleanup(void)
#endif
{
	if (DC_JZ4780DeInit() != DC_JZ4780_OK)
		printk (KERN_INFO DRVNAME ": DC_JZ4780_Cleanup: can't deinit device\n");
}

#if !defined(SUPPORT_DRI_DRM)
module_init(DC_JZ4780_Init);
module_exit(DC_JZ4780_Cleanup);
#endif
